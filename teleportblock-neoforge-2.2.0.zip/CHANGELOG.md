# Version 2.2.0

## Cross-Dimension Links
- Teleport Blocks can now be linked across dimensions - Overworld, Nether, End and modded dimensions
- Link them the same way as before: Shift+Right Click the first block, travel to another dimension, Shift+Right Click the second block
- Distance between dimensions uses Overworld-scale coordinates, just like vanilla portals: the Nether counts x8, so a block at 125, 0 in the Nether is right next to 1000, 0 in the Overworld
- Click, passive mode and ender pearl teleports all work across dimensions, with a portal sound on arrival
- Waystone links can now cross dimensions too
- Redstone relay works across dimensions while both blocks are loaded
- Jade shows the dimension of the paired block, and the F3 debug overlay shows its dimension id

## New Look and Sound
- Particles now depend on the block's state: unlinked blocks barely glow, linked blocks draw particles in, passive blocks pull them in from a ring around the block, cross-dimension blocks draw them in from all sides
- Particles fly in from farther away, so their path is easier to see
- Linked blocks send a few purple ender particles straight toward their partner
- Cross-dimension blocks hum quietly
- The first block you select while linking is outlined with soft white sparks
- Effects are now shown at a steady rate (previously a single block showed particles only every few seconds)
- Passive mode particles now really flow into the block
- New block sounds: placing the block sounds like charging a Respawn Anchor, breaking it like depleting one, and footsteps and hits sound like a Lodestone (replacing the placeholder amethyst sounds)
- New sounds have subtitles and can be replaced by resource packs
- Messages now show the Teleport Block icon and are colored by type: red for errors, yellow for cooldowns, green for success, purple for hints

## New Settings
- **Allow cross-dimension links** (on by default). Turning it off keeps existing links - they start working again when it's turned back on
- **Dimension blacklist** - dimensions that can't be linked to or from another dimension (for example `minecraft:the_end`). Links inside a blacklisted dimension still work
- **Extra XP cost between dimensions** - an optional flat cost on top of the distance cost. Free by default

## Compatibility
- **Open Parties and Claims**: players cannot teleport into chunks claimed by others, the same way as with FTB Chunks. Owners, their party and allies (per the claim's settings) can

## Fixes and Performance
- The teleport sound is no longer cut off: you now hear it fully at your destination, and players nearby hear it at both ends
- Map markers appear instantly after using a map on a linked block
- Map markers are refreshed only for maps in hand, instead of scanning every player's inventory
- Map markers now use world coordinates, so blocks on Create: Aeronautics ships no longer place markers far outside the map
- For a pair in different dimensions, only the block in the map's own dimension gets a marker
- Two pairs at the same coordinates in different dimensions no longer share a cooldown
- Breaking a block with an outdated link no longer unlinks its former partner's new pair
- The block now drops itself when mined with a pickaxe
- The REI info page for the block now shows up
- Carry On, Inventory Sorter and Create copycat blacklists now actually apply to the block

## Localization
- All new messages, settings and subtitles translated into all 14 languages
